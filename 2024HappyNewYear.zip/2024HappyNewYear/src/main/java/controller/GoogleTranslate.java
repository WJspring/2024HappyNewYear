//package controller;
//
//import java.io.BufferedReader;
//import java.io.InputStreamReader;
//import java.net.HttpURLConnection;
//import java.net.URL;
//import java.net.URLEncoder;
//
//public class GoogleTranslate {
//    public static void main(String[] args) {
//        try {
//            String textToTranslate = "Hello, world!"; // 要翻译的英文文本
//
//            String urlStr = "https://translate.googleapis.com/translate_a/single?client=gtx&sl=en&tl=zh-CN&dt=t&q=" + URLEncoder.encode(textToTranslate, "UTF-8");
//            URL url = new URL(urlStr);
//            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
//            conn.setRequestMethod("GET");
//
//            BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
//            StringBuilder response = new StringBuilder();
//            String line;
//            while ((line = reader.readLine()) != null) {
//                response.append(line);
//            }
//            reader.close();
//
//            // 从响应中提取翻译后的中文文本
//            String translation = response.toString().split("\"")[1];
//            System.out.println("翻译结果：" + translation);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }
//}
