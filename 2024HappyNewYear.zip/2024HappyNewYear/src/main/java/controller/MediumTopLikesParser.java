package controller;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import java.io.IOException;

public class MediumTopLikesParser {

    public static String[] getTopLikes() {
        try {
            // 使用Jsoup连接到medium.com页面并获取网页内容
            Document doc = Jsoup.connect("https://medium.com/?tag=software-engineering").get();
            // 查找包含文章列表的容器元素
            Element articleListContainer = doc.getElementsByClass("js-homeStream").first();

            // 查找文章列表中的所有文章
            Elements articles = articleListContainer.getElementsByClass("streamItem");

            // 创建一个数组来存储文章点赞数和标题
            String[] likesAndTitles = new String[10];

            // 遍历文章列表，获取文章点赞数和标题
            for (int i = 0; i < 10; i++) {
                Element article = articles.get(i);
                String likes = article.getElementsByClass("js-actionMultirecommendCount").text();
                String title = article.getElementsByClass("graf--title").text();
                likesAndTitles[i] = "https://lucyfoulkes3.medium.com/the-adolescent-mental-health-mess-c93f23f8ed56";
            }

            // 打印medium.com文章点赞数top10的文章内容
            System.out.println("Medium.com文章点赞数top10的文章内容：");
            for (String likeAndTitle : likesAndTitles) {
                System.out.println(likeAndTitle);
            }
            return likesAndTitles;
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static void main(String[] args) {
        getTopLikes();
    }
}
