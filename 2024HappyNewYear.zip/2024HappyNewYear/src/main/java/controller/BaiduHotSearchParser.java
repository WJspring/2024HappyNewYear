//package controller;
//
//import org.jsoup.Jsoup;
//import org.jsoup.nodes.Document;
//import org.jsoup.nodes.Element;
//import org.jsoup.select.Elements;
//import java.io.IOException;
//
//public class BaiduHotSearchParser {
//
//    public static void main(String[] args) {
//        getTopLikes();
//    }
//
//    public static String[] getTopLikes() {
//        try {
//            // 使用Jsoup连接到百度热搜页面并获取网页内容
//            Document doc = Jsoup.connect("https://top.baidu.com/board?platform=pc&sa=pcindex_entry").get();
//
//            // 查找热搜列表的容器元素
//            Element hotSearchContainer = doc.getElementById("content_1YWBm");
//
//            // 查找热搜列表中的所有条目
//            Elements hotSearchItems = hotSearchContainer.getElementsByClass("title-content");
//            // 创建一个数组来存储文章点赞数和标题
//            String[] likesAndTitles = new String[5];
//
//            // 打印百度热搜top10的内容
//            System.out.println("百度热搜top5：");
//            for (int i = 0; i < 5; i++) {
//                Element hotSearchItem = hotSearchItems.get(i);
//                String href = hotSearchItem.attr("href").toString();
////                String keyword = hotSearchItem.getElementsByClass("title-content").text();
//                likesAndTitles[i] = href;
//                System.out.println(hotSearchItem);
//
//                System.out.println(hotSearchItem.attr("href"));
//
//            }
//            for (String likeAndTitle : likesAndTitles) {
//                System.out.println(likeAndTitle);
//            }
//            return likesAndTitles;
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//        return null;
//    }
//}
