package controller;



import com.alibaba.fastjson2.JSONArray;
import com.alibaba.fastjson2.JSONObject;
import org.springframework.util.StringUtils;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class BaiduTranslate {

    public static String translation(int index, String query) {
        String appId = "XXX"; // 您的百度云应用ID
        String appKey = "XXX"; // 您的百度云应用密钥
        String fromLang = "en"; // 源语言为英文
        String toLang = "zh"; // 目标语言为中文
        //String query = "Hello, World!";XXX // 要翻译的文本

        try {
            String urlStr = "http://api.fanyi.baidu.com/api/trans/vip/translate?q=" + URLEncoder.encode(query, "UTF-8") +
                    "&from=" + fromLang + "&to=" + toLang + "&appid=" + appId + "&salt=1435660288&sign=" +
                    MD5Util.md5(appId + query + "1435660288" + appKey); // 构建请求URL
            URL url = new URL(urlStr);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");

            BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            StringBuilder response = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                response.append(line);
            }
            reader.close();

            if (!StringUtils.isEmpty(response)) {
                try{
                    System.out.println("翻译结果：" + convertUnicodeToCh(response.toString()));
                    JSONObject jsonObject = JSONObject.parseObject(response.toString());
                    JSONArray res = jsonObject.getJSONArray("trans_result");
                    if (null == res) {
                        System.out.println("翻译账号权限未设置或已失效");
                        return null;
                    }
                    return convertUnicodeToCh(res.toString());
                }catch (Exception e) {
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    private static String convertUnicodeToCh(String str) {
        Pattern pattern = Pattern.compile("(\\\\u(\\w{4}))");
        Matcher matcher = pattern.matcher(str);

        // 迭代，将str中的所有unicode转换为正常字符
        while (matcher.find()) {
            String unicodeFull = matcher.group(1); // 匹配出的每个字的unicode，比如\u67e5
            String unicodeNum = matcher.group(2); // 匹配出每个字的数字，比如\u67e5，会匹配出67e5

            // 将匹配出的数字按照16进制转换为10进制，转换为char类型，就是对应的正常字符了
            char singleChar = (char) Integer.parseInt(unicodeNum, 16);

            // 替换原始字符串中的unicode码
            str = str.replace(unicodeFull, singleChar + "");
        }
        return str;
    }

    public static void main(String[] args) {
        translation(1,"In July 2021, UK Banker Magazine released “Top 1000 Bank in the world” list, and TFB is ranked at 441 place.");
    }
}
