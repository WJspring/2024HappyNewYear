package controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

@Controller
public class PDFController {
    @GetMapping("/")
    public String index() {
        return "index";
    }

    @PostMapping("/createPDFs")
    @ResponseBody
    public String createPDFs() {
        begin();
        return "PDF文件已生成";
    }

    @GetMapping("/download")
    public void download() {
        try {
            // 创建一个Zip文件并添加生成的PDF文件
            FileOutputStream fos = new FileOutputStream("output.zip");
            ZipOutputStream zipOut = new ZipOutputStream(fos);
            for (int i = 1; i <= 10; i++) {
                File fileToZip = new File("page" + i + ".pdf");
                zipOut.putNextEntry(new ZipEntry(fileToZip.getName()));
                zipOut.write(fileToZipToBytes(fileToZip));
                zipOut.closeEntry();
            }
            zipOut.close();
            fos.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void begin(){
        // 使用Jsoup来解析网页内容并获取medium.com文章点赞数top10的英文文章内容
        String[] top_10_pages = MediumTopLikesParser.getTopLikes();
        for (int i = 1; i <= top_10_pages.length; i++) {
            // 将英文翻译为中文
            // 生成PDF文件并保存
            WebPageToPDF.writeWebToPDF(i, top_10_pages[i]);
        }
    }

    private byte[] fileToZipToBytes(File file) throws IOException {
        FileInputStream fis = new FileInputStream(file);
        byte[] fileBytes = new byte[(int) file.length()];
        fis.read(fileBytes);
        fis.close();
        return fileBytes;
    }

    public static void main(String[] args) {
//        PDFWriter.writeToPDF(1, TranslationClient.translation(1, "CreditCard Fraud Detection Using Machine Learning & Python"));

//        TranslationClient.translation(1, "CreditCard Fraud Detection Using Machine Learning & Python");

        //GeneratePDF.writeTextToPDF(1, "CreditCard Fraud Detection Using Machine Learning & Python");
//         WebPageToPDF.writeWebToPDF(1,"https://dnastacio.medium.com/hierarchy-of-career-priorities-c18768d32598");
        begin();
    }
}
