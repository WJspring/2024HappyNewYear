//package controller;
//
//import java.io.BufferedReader;
//import java.io.InputStreamReader;
//import java.io.OutputStream;
//import java.net.HttpURLConnection;
//import java.net.URL;
//
//public class ChatGPTClient {
//    public static void main(String[] args) {
//        try {
//            // ChatGPT API endpoint
//            String endpoint = "https://api.openai.com/v1/engines/davinci-codex/completions";
//
//            // 设置请求头
//            String apiKey = "YOUR_API_KEY";  // 替换为您的OpenAI API密钥
//            String requestData = "{\"prompt\": \"Once upon a time\", \"max_tokens\": 150}";
//
//            URL url = new URL(endpoint);
//            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
//
//            // 设置请求方法
//            connection.setRequestMethod("POST");
//            connection.setRequestProperty("Content-Type", "application/json");
//            connection.setRequestProperty("Authorization", "Bearer " + apiKey);
//            connection.setDoOutput(true);
//
//            // 发送请求
//            OutputStream os = connection.getOutputStream();
//            os.write(requestData.getBytes());
//            os.flush();
//            os.close();
//
//            // 处理响应
//            BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
//            String inputLine;
//            StringBuffer response = new StringBuffer();
//            while ((inputLine = in.readLine()) != null) {
//                response.append(inputLine);
//            }
//            in.close();
//
//            // 打印响应
//            System.out.println(response.toString());
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }
//}
