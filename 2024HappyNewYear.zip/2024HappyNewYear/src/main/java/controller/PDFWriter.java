//package controller;
//
//import org.apache.pdfbox.pdmodel.PDDocument;
//import org.apache.pdfbox.pdmodel.PDPage;
//import org.apache.pdfbox.pdmodel.PDPageContentStream;
//import org.apache.pdfbox.pdmodel.font.PDType1Font;
//
//import java.io.File;
//import java.io.IOException;
//
//public class PDFWriter {
//    public static void writeToPDF(int index, String translatedText) {
//        try {
//            // 创建一个PDDocument对象
//            PDDocument document = new PDDocument();
//            PDPage page = new PDPage();
//
//            // 添加页面到文档
//            document.addPage(page);
//
//            // 创建一个PDPageContentStream对象
//            PDPageContentStream contentStream = new PDPageContentStream(document, page);
//
//            // 设置字体和字体大小
//            contentStream.setFont(PDType1Font.SYMBOL, 12);
//
//            // 写入翻译后的中文文本到页面
//            contentStream.beginText();
//            contentStream.newLineAtOffset(25, 700); // 设置起始位置
//            contentStream.showText(translatedText);
//            contentStream.endText();
//
//            // 关闭contentStream
//            contentStream.close();
//
//            // 保存文档
//            document.save(new File("page" + index + ".pdf"));
//
//            // 关闭文档
//            document.close();
//
//            System.out.println("PDF文件: page"+ index +".pdf 已生成");
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//    }
//}
