//package controller;
//
//import java.io.*;
//import java.net.HttpURLConnection;
//import java.net.URL;
//
//public class TranslationClient {
//
//    public static String translation(int index, String inputText) {
//        try {
//            // 读取英文文件内容到字符串
////            File inputFile = new File("english.txt");
////            BufferedReader reader = new BufferedReader(new FileReader(inputFile));
////            StringBuilder inputText = new StringBuilder();
////            String line;
////            while ((line = reader.readLine()) != null) {
////                inputText.append(line);
////            }
////            reader.close();
//
//            // ChatGPT API endpoint
//            String endpoint = "https://api.openai.com/v1/engines/davinci-codex/completions";
//
//            // 设置请求头
//            String apiKey = "YOUR_API_KEY";  // OpenAI API密钥
//            String requestData = "{\"prompt\": \"" + inputText.toString() + "\", \"max_tokens\": 150, \"target_language\": \"zh\"}";
//
//            URL url = new URL(endpoint);
//            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
//
//            // 设置请求方法
//            connection.setRequestMethod("POST");
//            connection.setRequestProperty("Content-Type", "application/json");
//            connection.setRequestProperty("Authorization", "Bearer " + apiKey);
//            connection.setDoOutput(true);
//
//            // 发送请求
//            OutputStream os = connection.getOutputStream();
//            os.write(requestData.getBytes());
//            os.flush();
//            os.close();
//
//            // 处理响应
//            BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
//            String inputLine;
//            StringBuffer response = new StringBuffer();
//            while ((inputLine = in.readLine()) != null) {
//                response.append(inputLine);
//            }
//            in.close();
//
//            // 从API响应中提取翻译后的中文文本
//            String translatedText = extractTranslatedText(response.toString());
//
//            // 将翻译后的中文文本写入文件
////            File outputFile = new File("chinese.txt");
////            BufferedWriter writer = new BufferedWriter(new FileWriter(outputFile));
////            writer.write(translatedText);
////            writer.close();
//            System.out.println("翻译: page"+ index +"已翻译完成");
//
//            return translatedText;
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        return null;
//    }
//
//    // 从API响应中提取翻译后的中文文本
//    private static String extractTranslatedText(String response) {
//        // 这里简单地假设API响应是一个JSON字符串，并直接提取翻译后的文本
//        //TODO 默认返回
//        return response;
//    }
//}
