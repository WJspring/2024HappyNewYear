//package controller;
//
//import com.itextpdf.text.Document;
//import com.itextpdf.text.Paragraph;
//import com.itextpdf.text.pdf.PdfWriter;
//
//import java.io.FileOutputStream;
//
//public class GeneratePDF {
//
//
//    public static void main(String[] args) {
//        writeTextToPDF(1, "");
//    }
//
//    public static void writeTextToPDF(int index, String translatedText) {
//        try {
//            Document pdfDocument = new Document();
//            PdfWriter.getInstance(pdfDocument, new FileOutputStream("page" + index + ".pdf"));
//            pdfDocument.open();
//            pdfDocument.add(new Paragraph(translatedText));
//            pdfDocument.close();
//            System.out.println("PDF文件: page"+ index +".pdf 已生成");
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }
//
//}