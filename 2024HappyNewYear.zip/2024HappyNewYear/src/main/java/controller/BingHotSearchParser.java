//package controller;
//
//import org.jsoup.Jsoup;
//import org.jsoup.nodes.Document;
//import org.jsoup.nodes.Element;
//import org.jsoup.select.Elements;
//import java.io.IOException;
//
//public class BingHotSearchParser {
//    public static void main(String[] args) {
//        try {
//            // 使用Jsoup连接到bing首页并获取网页内容
//            Document doc = Jsoup.connect("https://cn.bing.com").get();
//
//            // 查找包含热搜列表的容器元素
//            Element hotSearchContainer = doc.getElementById("sw_as");
//
//            // 查找热搜列表中的所有条目
//            Elements hotSearchItems = hotSearchContainer.getElementsByClass("sw_ad");
//
//            // 打印bing热搜top10的内容
//            System.out.println("Bing热搜top10：");
//            for (int i = 0; i < 10; i++) {
//                Element hotSearchItem = hotSearchItems.get(i);
//                String rank = hotSearchItem.getElementsByClass("sw_adtitle").text();
//                System.out.println(rank);
//            }
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//    }
//}
