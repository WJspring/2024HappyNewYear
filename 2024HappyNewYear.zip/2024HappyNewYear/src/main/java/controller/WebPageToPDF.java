package controller;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Image;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.BaseFont;
import com.itextpdf.text.pdf.PdfWriter;
import com.itextpdf.text.pdf.StringUtils;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URL;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class WebPageToPDF {
    public static void main(String[] args) {
        writeWebToPDF(1, "https://www.tf.cn/tfyh_english/tfjj/");
    }

    public static void writeWebToPDF(int index, String url) {
        Document pdfDocument = null;
        try {
            org.jsoup.nodes.Document doc = Jsoup.connect(url).get();
            Elements elements = doc.select("img, p"); // 选择网页中的图片和文本内容
            pdfDocument = new Document();
            PdfWriter.getInstance(pdfDocument, new FileOutputStream("page" + index + ".pdf"));
            pdfDocument.open();
            // windows指定中文字体
            BaseFont chineseFont = BaseFont.createFont("C:\\Windows\\Fonts\\simsun.ttc,0", BaseFont.IDENTITY_H, BaseFont.EMBEDDED);
            com.itextpdf.text.Font font = new com.itextpdf.text.Font(chineseFont, 12);

            for (Element element : elements) {
                if (element.tagName().equals("img")) {
                    String imageUrl = element.absUrl("src");
                    Image image = Image.getInstance(new URL(imageUrl));
                    pdfDocument.add(image);
                } else if (element.tagName().equals("p")) {
                    String text = element.text();
                    // 定义匹配英文单词的正则表达式
                    String regex = "\\b[a-zA-Z]+\\b";
                    Pattern pattern = Pattern.compile(regex);
                    Matcher matcher = pattern.matcher(text);
                    if (matcher.find()) {
                        try {
                            Thread.sleep(1000);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                        String trsText = BaiduTranslate.translation(index, text);
                        if(null != trsText) {
                            pdfDocument.add(new Paragraph(trsText, font));
                        } else {
                            pdfDocument.add(new Paragraph(text));
                        }
                    } else {
                        pdfDocument.add(new Paragraph(text));
                    }
                }
            }

            System.out.println("PDF文件: page"+ index +".pdf 已生成");
        } catch (IOException | DocumentException e) {
            e.printStackTrace();
        } finally {
            if (null != pdfDocument) {
                pdfDocument.close();
            }
        }
    }

}
